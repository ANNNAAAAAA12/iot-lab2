#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <mbedtls/md.h>
#include <mbedtls/base64.h>

const char* ID_SCOPE = "0ne010B81EB";
const char* DEVICE_ID = "esp32-wokwi-01";
const char* PRIMARY_KEY = "IRrqiazJyBWP0HdAHOZV3W1EImTudCY6IS247hbvl=";

#define DHTPIN 15
#define DHTTYPE DHT22
#define POTPIN 34
#define LEDPIN 2

DHT dht(DHTPIN, DHTTYPE);
WiFiClientSecure espClient;
PubSubClient client(espClient);

String urlEncode(String str) {
  String encoded = "";
  char c, code0, code1;
  for (int i = 0; i < str.length(); i++) {
    c = str.charAt(i);
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
      encoded += c;
    } else {
      code0 = (c >> 4) & 0xF;
      code1 = c & 0xF;
      encoded += '%';
      encoded += (char)(code0 > 9 ? code0 - 10 + 'A' : code0 + '0');
      encoded += (char)(code1 > 9 ? code1 - 10 + 'A' : code1 + '0');
    }
  }
  return encoded;
}

String generateSASToken(String resourceUri, String key, long ttl) {
  long expiry = time(NULL) + ttl;
  if (expiry < 1700000000) expiry = 1893456000;

  String stringToSign = resourceUri + "\n" + String(expiry);
  unsigned char keyDecoded[64];
  size_t keyLen = 0;
  mbedtls_base64_decode(keyDecoded, sizeof(keyDecoded), &keyLen, (const unsigned char*)key.c_str(), key.length());

  unsigned char hmacResult[32];
  mbedtls_md_context_t ctx;
  mbedtls_md_setup(&ctx, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1);
  mbedtls_md_hmac_starts(&ctx, keyDecoded, keyLen);
  mbedtls_md_hmac_update(&ctx, (const unsigned char*)stringToSign.c_str(), stringToSign.length());
  mbedtls_md_hmac_finish(&ctx, hmacResult);
  mbedtls_md_free(&ctx);

  unsigned char sigBase64[64];
  size_t sigLen = 0;
  mbedtls_base64_encode(sigBase64, sizeof(sigBase64), &sigLen, hmacResult, 32);
  sigBase64[sigLen] = '\0';

  return "SharedAccessSignature sr=" + urlEncode(resourceUri) + "&sig=" + urlEncode((char*)sigBase64) + "&se=" + String(expiry) + "&skn=registration";
}

void callback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) message += (char)payload[i];
  Serial.println("Comando/Mensaje recibido: " + message);

  if (message.indexOf("setAlertLed") != -1 || message.indexOf("true") != -1) {
    digitalWrite(LEDPIN, HIGH);
    Serial.println("-> LED Encendido por comando");
  } else if (message.indexOf("false") != -1) {
    digitalWrite(LEDPIN, LOW);
    Serial.println("-> LED Apagado por comando");
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LEDPIN, OUTPUT);
  dht.begin();

  WiFi.begin("Wokwi-GUEST", "");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Conectado!");

  espClient.setInsecure();
  client.setServer("global.azure-devices-provisioning.net", 8883);
  client.setCallback(callback);

  String username = String(ID_SCOPE) + "/registrations/" + String(DEVICE_ID) + "/api-version=2019-03-31";
  String resourceUri = String(ID_SCOPE) + "/registrations/" + String(DEVICE_ID);
  String password = generateSASToken(resourceUri, PRIMARY_KEY, 3600);

  if (client.connect(DEVICE_ID, username.c_str(), password.c_str())) {
    Serial.println("¡ESP32 Conectado exitosamente!");
    client.subscribe("devices/+/messages/devicebound/#");
  } else {
    Serial.print("Error MQTT: ");
    Serial.println(client.state());
  }
}

void loop() {
  client.loop();
  static unsigned long lastMsg = 0;
  if (millis() - lastMsg > 5000) {
    lastMsg = millis();
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    int potValue = analogRead(POTPIN);
    float iluminacion = map(potValue, 0, 4095, 0, 1000);

    if (isnan(h) || isnan(t)) { h = 50.0; t = 24.0; }

    StaticJsonDocument<200> doc;
    doc["temperatura"] = t;
    doc["humedad"] = h;
    doc["iluminacion"] = iluminacion;

    char jsonBuffer[512];
    serializeJson(doc, jsonBuffer);
    client.publish(("devices/" + String(DEVICE_ID) + "/messages/events/").c_str(), jsonBuffer);

    Serial.print("Telemetría enviada: ");
    Serial.println(jsonBuffer);
  }
}